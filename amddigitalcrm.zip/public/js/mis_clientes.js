var table;
$(window).load(function() {
    table = $('.datatable').DataTable({
        "ajax": {
            "url": '../../MisClientes/Mostrar',
            "dataSrc": ""
        },
        "columns": [{
            "data": "contador"
        }, {
            "data": "id_origen"
        }, {
            "data": "fecha_hora"
        }, {
            "data": "empresa"
        }, {
            className: "centrar_td",
            "render": function(data, type, full, meta) {
                return "<img class='img_datatable_c' src='../../public/img/envelope.svg' alt='' onclick='MandarMensaje(\"" + full.id + "\",\"" + full.id_usuario_asignado + "\")'><br/><button class='btn btn-xs btn-amdigital'>Historial</button>";
            }
        }, {
            className: "centrar_td",
            "render": function(data, type, full, meta) {
                return "<img class='img_datatable_c' src='../../public/img/sms.svg' alt=''><br/><button class='btn btn-xs btn-amdigital'>Historial</button>";
            }
        }, {
            className: "centrar_td",
            "render": function(data, type, full, meta) {
                return "<img class='img_datatable_c' src='../../public/img/notes.svg' alt=''><br/><button class='btn btn-xs btn-amdigital'>Historial</button>";
            }
        }, {
            "data": "id_ubigeo"
        }, {
            "data": "mensaje"
        }, ],
    });
});
$(document).ready(function() {});

function modificar(id) {
    $.ajax({
        url: '../ClientesGeneral/AceptarCliente/' + id,
        type: "POST",
        success: function(data) {
            table.ajax.reload();
        }
    });
}

function MandarMensaje(cliente_id, usario_id) {
    $.ajax({
        url: '../MisClientes/MandarMensaje',
        type: "POST",
        data: {
            'cliente_id': cliente_id,
            'cuerpo': 'hoy es 02/09/2019 y estares gsutos de atenderlo',
            'usario_id': usario_id,
        },
        success: function(data) {
            alert(data);
        }
    });
}