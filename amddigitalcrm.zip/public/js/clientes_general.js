$(function () {
    var table;
    const app = new Vue({
        el: '#app',
        data: {
            dataTable: null,
            clientes: [],
        },
        computed :{
            ...Vuex.mapState(['numeroclientes']),
        },
        created() {
            this.LlamarClientes();
        },
        beforeUpdate: function () {
            if (this.dataTable) {
                this.dataTable.destroy()
            }
        },
        updated: function () {
            this.dataTable = $('.datatable').DataTable()
        },
        methods: {
            
            LlamarClientes: function () {
                var url = URLPRINCIPAL + 'ClientesGeneral/Mostrar';
                this.$http.get(url, {
                    before: function () {
                    },
                }).then(
                    response => {
                        this.clientes = response.body;
                    }, response => { });
            },
            AdministrarCliente: function (id) {
                var url = URLPRINCIPAL + 'ClientesGeneral/AceptarCliente/' + id;
                this.$http.get(url).then(response => {
                    alertify.notify('<b>Se asigno cliente correctamente</b>', 'custom-black', TIEMPO_NOTIFICACION, function () { });
                    this.LlamarClientes();
                }, response => { });
            },
        },
    });
});

