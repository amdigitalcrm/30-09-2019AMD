const vue = new Vue({});
const store = new Vuex.Store({
    state: {
        numeroclientes: 0,


    },
    mutations: {
        LlamarContadorClientes: function (state) {
            var url = URLPRINCIPAL + 'ClientesGeneral/ContadorMostrar';
            vue.$http.post(url).then(
                response => {
                    state.numeroclientes = response.body[0].numero_clientes;
                }, response => { });
        },
        ActivarSocket: function (state) {
            var self = state;
            try {
                self.ws = new WebSocket('ws://127.0.0.1:8080/chat');
            } catch (error) {
                console.log(error);
            }
            self.ws.onopen = function (e) {
            };
            self.ws.onmessage = function (e) {
                alert(e.data);
            };
            self.ws.onerror = function (e) {
            };
            self.ws.onclose = function (e) {
            };
        }
    },
    actions: {},
});
