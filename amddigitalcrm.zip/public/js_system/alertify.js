function abrir_modal(nombre, title) {
    alertify.dialog(nombre, function() {
        return {
            main: function(content) {
                this.setContent(content);
            },
            setup: function() {
                return {
                    focus: {
                        element: function() {
                            return this.elements.body.querySelector(this.get('selector'));
                        },
                        select: true
                    },
                    options: {
                        basic: false,
                        title: title,
                        maximizable: true,
                        resizable: false,
                        padding: true,
                        modal: true,
                        transition: false,
                        pinnable: true,
                    }
                };
            },
            settings: {
                selector: undefined
            }
        };
    });
}